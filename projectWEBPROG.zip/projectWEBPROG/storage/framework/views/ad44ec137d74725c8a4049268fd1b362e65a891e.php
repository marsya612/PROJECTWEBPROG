<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
      #footer{
        position: relative;
        margin-top: 100%;
        height: 230px;
        padding-top: 35em;
        margin-top: 10px;
              
      }
      
    </style>



</head>

<body>
    
    <div class="header fixed-top">
        <nav class="navbar" style="background-color: #5D6B6B">
            <div class="container-fluid">
              <span class="navbar-brand mb-0 h1 text-white">MaejangGo</span>
              <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
                <div class="offcanvas-header">
                  <h5 class="offcanvas-title" id="offcanvasNavbarLabel">MaejangGo</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                </div>
                <div class="offcanvas-body">
                  <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
                    <li class="nav-item">
                      <a class="nav-link active" aria-current="page" href="/">Home</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="/booking">Booking</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/chat">Chat</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/faq">FAQ</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/aboutus">About Us</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
        </nav>
    </div>
    

    
    <?php echo $__env->yieldContent('content'); ?>
    

    <?php echo $__env->yieldContent('content2'); ?>
    
    <span id="footer">
      <footer class="justify-content-between align-items-center py-3 border-to text-white" style="background-color: #5D6B6B">
        <div class="container d-flex justify-content-between">
            <div class="col-md-4 align-items-center text-white">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">BINUS</a>
                <span class="mb-3 mb-md-0 text-body-secondary-white">&copy; <?php echo e(date("Y")); ?> MaejangGO</span>
            </div>
        </div>
      </footer>
    </span>
    
    
    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/projectWEBPROG/resources/views/layout.blade.php ENDPATH**/ ?>