<?php

namespace App\Http\Controllers;
use App\Models\maejangGO;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class maeGOcontroller extends Controller
{
    //
    // public function product(){
    //     $products = DB::table('product')->get();
    //     return view('detailfact',[
    //         'products'=> $products
    //     ]);
    // }
    public function Showproduct(){
        $products = maejangGO::all();
        dd($products);
        return view('detailfact', [
            'products' => $products
        ]);
    }
}
