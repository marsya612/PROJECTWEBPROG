<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('product')->insert([
            'id' => 1,
            'Product_Name' => 'The 5th Album [Fact Check] (Chandelier Ver.)',
            'price' => 375.000,
            'Release date' => '2023-10-06',
            'Title' => 'Fact Check (불가사의; 不可思議)',
            'content' => json_encode([
                'PHOTOBOOK COVER' => '1 ver. / 185*254mm',
                'BOOKLET' => '128p - STICKER : 4ea 1 set',
                'FOLDED POSTER' => '1 ver.',
                'PHOTO' => 'random 1 out of 9 versions',
                'PHOTOCARD' => 'random 1 out of 9 versions',
            ]),
            'manufacturer' => 'KAKAO M',
            'country' => 'KOREA'
        ]);
    }
}
