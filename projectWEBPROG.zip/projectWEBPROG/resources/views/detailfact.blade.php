@extends('layout')
@section('content')
<div class="mt-5 p-3">
    <div class="row g-3 m-4 position-relative">
        <div class="col-md-5 mb-md-0 p-md-3">
            <img src="/NCTALBUM/factcheck.png" class="w-100" alt="...">
        </div>
        <div class="col-md-6 p-7 ps-md-0">
            <h5 class="mt-0">The 5th Album [Fact Check] (Chandelier Ver.)</h5>
            <table class="table caption-top">
                <caption>Information</caption>
                <tbody>
                <tr>
                    
                    <th scope="row" class="table-active">Product Name</th>
                    <td>The 5th Album [Fact Check] (Chandelier Ver.)</td>
                    {{-- @foreach ($products as $products)
                        {{$products->Product_Name}}
                    @endforeach --}}

                    {{-- <td>{{$products->Product_Name}}</td> --}}
                </tr>
                <tr>
                    <th scope="row" class="table-active">Price</th>
                    <td>Rp375,000.00</td>
                </tr>
                <tr>
                    <th scope="row" class="table-active">Release date</th>
                    <td>2023.10.06</td>
                </tr>
                <tr>
                    <th scope="row" class="table-active">Title</th>
                    <td>Fact Check (불가사의; 不可思議)</td>
                </tr>
                <tr>
                    <th scope="row" class="table-active">Contents</th>
                    <td>
                        <ul>
                            <li>PHOTOBOOK COVER : 1 ver. / 185*254mm</li>
                            <li>BOOKLET : 128p - STICKER : 4ea 1 set</li>
                            <li>FOLDED POSTER : 1 ver.</li>
                            <li>PHOTO : random 1 out of 9 versions</li>
                            <li>PHOTOCARD : random 1 out of 9 versions</li>
                        </ul>
                    </td>
                </tr>
                <tr>
                    <th scope="row" class="table-active">Manufacturer</th>
                    <td>KAKAO M</td>
                </tr>
                <tr>
                    <th scope="row" class="table-active">Country of manufacture</th>
                    <td>KOREA</td>
                </tr>
                </tbody>
            </table>  
            <div class="row g-4 md-2">
                <div class="col-md">
                <div class="button">
                    <a href="/booking" class="btn btn-primary justify-content-md-end">Checkout</a>
                </div>
                </div>
                <div class="col-md">
                    <select class="form-select">
                        <option selected>Open this select payment method</option>
                        <option value="1">BCA</option>
                        <option value="2">MANDIRI</option>
                        <option value="3">GOPAY</option>
                    </select>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection